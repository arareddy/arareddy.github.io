import random
import string

def firstfit(instance, binsize):
	used_bin = [0]
	for i in range(0, len(instance)): 
		flag = 0
		for j in range(0, len(used_bin)):
			if used_bin[j] + instance[i] <= binsize:
				used_bin[j] = used_bin[j] + instance[i]
				flag = 1
				break
		if flag == 0:
			used_bin.append(instance[i])
	return len(used_bin)


def firstfitdecreasing(instance, binsize):
	instance.sort(reverse=True)
	return firstfit(instance, binsize)


def bestfit(instance, binsize):
	used_bin = [0]
	for i in range(0, len(instance)): 
		min_j = -1
		min_bin = binsize + 1
		for j in range(0, len(used_bin)):
			if used_bin[j] + instance[i] <= binsize and used_bin[j] < min_bin:
				min_j = j
				min_bin = used_bin[j]
		if min_j == -1:
			used_bin.append(instance[i])
		else: 
			used_bin[min_j] = used_bin[min_j] + instance[i]
	return len(used_bin)


def bestfitdecreasing(instance, binsize):
	instance.sort(reverse=True)
	return bestfit(instance, binsize)


def readfile(filename):
	f = open(filename, "r")
	fi = f.readlines()
	item_num = int(fi[0])
	binsize = int(fi[1])
	instance = []
	for i in range(2, item_num+2):
		instance.append(int(fi[i]))
	f.close()
	return instance, binsize


def parsebest(filename):
	bestnum = []
	f = open(filename, "r")
	fi = f.readlines()
	for line in fi:
		linelist = line.split("\t")
		if (len(linelist) < 5):
			bestnum.append(int(linelist[1]))
			break
		bestnum.append(int(linelist[1]))
		bestnum.append(int(linelist[3]))
		bestnum.append(int(linelist[5]))
	return bestnum


def getdataset1():
	namepath = "bin1data/"
	bestnum = parsebest(namepath + "best.txt")
	f = open("result1.txt", "w")
	vlist = string.ascii_uppercase[:20]
	i = 0
	for x in range(1, 5):
		for y in range(1, 4):
			for z in range(1, 4):
				if z == 3:
					z = z+1
				for v in vlist:
					filename = "N"+str(x)+"C"+str(y)+"W"+str(z)+"_"+v
					instance, binsize = readfile(namepath+filename+".bpp")
					random.shuffle(instance)
					firstfitnum = str(firstfit(instance, binsize))
					bestfitnum = str(bestfit(instance, binsize))
					firstfitdecreasingnum = str(firstfitdecreasing(instance, binsize))
					bestfitdecreasingnum = str(bestfitdecreasing(instance, binsize))
					f.write(filename + " " + firstfitnum + " " + firstfitdecreasingnum + " " + bestfitnum + " " + bestfitdecreasingnum + " " + str(bestnum[i]) + "\n")
					i = i+1
	f.close()


def getdataset2():
	namepath = "bin2data/"
	bestnum = parsebest(namepath + "best.txt")
	f = open("result2.txt", "w")
	i = 0
	for x in range(1, 5):
		for y in range(1, 5):
			for z in range(1, 4):
				for v in range(0, 10):
					filename = "N"+str(x)+"W"+str(y)+"B"+str(z)+"R"+str(v)
					instance, binsize = readfile(namepath+filename+".bpp")
					random.shuffle(instance)
					firstfitnum = str(firstfit(instance, binsize))
					bestfitnum = str(bestfit(instance, binsize))
					firstfitdecreasingnum = str(firstfitdecreasing(instance, binsize))
					bestfitdecreasingnum = str(bestfitdecreasing(instance, binsize))
					f.write(filename + " " + firstfitnum + " " + firstfitdecreasingnum + " " + bestfitnum + " " + bestfitdecreasingnum + " " + str(bestnum[i]) + "\n")
					i = i+1
	f.close()


def getdataset3():
	namepath = "bin3data/"
	bestnum = parsebest(namepath + "best.txt")
	f = open("result3.txt", "w")
	i = 9
	for x in range(0, 10):
		filename = "HARD"+str(x)
		instance, binsize = readfile(namepath+filename+".bpp")
		random.shuffle(instance)
		firstfitnum = str(firstfit(instance, binsize))
		bestfitnum = str(bestfit(instance, binsize))
		firstfitdecreasingnum = str(firstfitdecreasing(instance, binsize))
		bestfitdecreasingnum = str(bestfitdecreasing(instance, binsize))
		f.write(filename + " " + firstfitnum + " " + firstfitdecreasingnum + " " + bestfitnum + " " + bestfitdecreasingnum + " " + str(bestnum[i]) + "\n")
		i = i+1
		if i == 10:
			i = 0
	f.close()


def main():
	getdataset1()
	getdataset2()
	getdataset3()


if __name__ == '__main__':
    main()






